import React, { useState } from 'react';
import { useHistory } from "react-router-dom";

export const CreatePage = () => {

    const [name, setName] =useState();
    const [reps, setReps] =useState();
    const [weight, setWeight] =useState();
    const [unit, setUnit]=useState('lbs');
    const [date, setDate] =useState();

    const history = useHistory();

    const addExercise = async () => {
        const newExercise = {name, reps, weight, unit, date};
        const response = await fetch('/exercises',{
            method: 'POST',
            body: JSON.stringify(newExercise),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        if (response.status === 201){
            alert ("Successfully added exercises");
        } else{
            alert (`Failed to add exercises, status code = ${response.status}`);
        }
        history.push("/");
    };

    return (
        <fieldset>
            <h1>Add an Exercise</h1>
            <p>Enter your completed exercise information here</p>
            <form>
            <label> Name:
            <input
                type="text" 
                placeholder="enter name of exercise" 
                value={name} 
                onChange={e => setName(e.target.value)}
                maxLength="35" size="40"required />
                </label>
                </form>
            <form>
            <label> Repetitions:
            <input
                type="number" 
                value={reps} 
                placeholder="# of repetitions" 
                onChange={e => setReps(e.target.value)}
                maxLength="4" size="5"required />
                </label>
                </form>
            <form>
            <label> Weights Utilized:
            <input
                type="number" 
                value={weight} 
                placeholder="weight of the weights used" 
                onChange={e => setWeight(e.target.value)} 
                maxLength="4" size="5"required />
                </label>
                </form>
            <form>
            <label> Units:
            <select 
                type="text"
                value={unit}
                onChange={e => setUnit(e.target.value)}>
                <option value='lbs'>lbs</option>
                <option value='kgs'>kgs</option>
                </select>
                </label>
                </form>
            <form>
            <label> Date:
            <input
                type="date" 
                value={date} 
                pattern="(?:19|22)\[0-9\]{2}-(?:(?:0\[1-9\]|1\[0-2\])-(?:0\[1-9\]|1\[0-9\]|2\[0-9\])|(?:(?!02)(?:0\[1-9\]|1\[0-2\])-(?:30))|(?:(?:0\[13578\]|1\[02\])-31))"
                onChange={e => setDate(e.target.value)} />
                </label>
                </form>
                <br></br>
            <button onClick={addExercise}>Add</button>
        </fieldset>
        
);

    }


export default CreatePage;