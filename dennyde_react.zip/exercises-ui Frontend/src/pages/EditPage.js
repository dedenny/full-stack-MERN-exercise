// import dependencies
import React, { useState } from 'react';
import { useHistory } from "react-router-dom";

//edit function
export const EditPage = ({ exercise }) => {
    const [name, setName] = useState(exercise.name);
    const [reps, setReps] = useState(exercise.reps);
    const [weight, setWeight] = useState(exercise.weight);
    const [unit, setUnit] = useState(exercise.unit);
    const [date, setDate] = useState(exercise.date);

    const history = useHistory();
   
    const editExercise = async () => {
        //const editExercise = {name, reps, weight, unit, date}
         await fetch(`/exercises/${exercise._id}`, {
            method: 'PUT',
            body: JSON.stringify({
                name: name,
                reps: reps,
                weight: weight,
                unit: unit,
                date: date
            }), headers: {
                'Content-Type': 'application/json',
            },
        });
       // if (response.status === 200){
         //   alert ("Successfully edited exercises");
       // } else{
        //   alert (`Failed to edit exercises, status code = ${response.status}`);
        
        history.push("/");
        alert ("Successfully edited exercises");
    };

    return (
    <fieldset>
            <h2>Edit Exercises</h2>
            <p>Here you can edit and update past exercises</p>
        <form>
        <label> Name:
        <input
            type="text"
            placeholder="name of exercise"
            value={name}
            onChange={e => setName(e.target.value)} 
            maxLength= "35" size= "40" required />
            </label>
            </form>
        <form>
        <label> Repetitions:
        <input
            type="number"
            value={reps}
            placeholder="# of repetitions" 
            onChange={e => setReps(e.target.value)} 
            maxLength= "3" size= "4" required />
            </label>
            </form>
        <form>
        <label> Weights Utilized:
        <input
            type="number"
            value={weight}
            placeholder="weight of the weights used" 
            onChange={e => setWeight(e.target.value)} 
            maxLength="4" size="5" required />
            </label>
            </form>
        <form>
        <label> Units:
        <select 
            type="text"
            value={unit}
            onChange={e => setUnit(e.target.value)}>
            <option value= 'lbs'>lbs</option>
            <option value= 'kgs'>kgs</option>
            </select>
            </label>
            </form>
        <form>
        <label> Date:
        <input
             type="date"
             value= {date}
             onChange={e => setDate(e.target.value)}
             pattern="(?:19|22)\[0-9\]{2}-(?:(?:0\[1-9\]|1\[0-2\])-(?:0\[1-9\]|1\[0-9\]|2\[0-9\])|(?:(?!02)(?:0\[1-9\]|1\[0-2\])-(?:30))|(?:(?:0\[13578\]|1\[02\])-31))" />
            </label>
            </form>
            <br></br>
        <button onClick = {editExercise}>Save</button>
    </fieldset>
        
    )
    
}
export default EditPage;