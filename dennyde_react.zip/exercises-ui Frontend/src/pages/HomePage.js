
// import dependencies
import React from 'react';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';

// import components
import LogTable from '../components/LogTable';

// use SPA to render home page content & history below
//& state to bring in the data
function HomePage({ setExercise }) {
    const history = useHistory ();
    const [exercises, setExercises] = useState([]);


    // retrieves the list of exercises
    const loadExercises = async () => {
        const response = await fetch ('/exercises');
        const exercises = await response.json();
        setExercises(exercises);
    }

// edit exercises
    const onEditExercise = async exercise => {
        setExercise(exercise);
        history.push("/edit-exercises");
    }

// delete exercises as applicable
    const onDeleteExercise = async _id => {
        const response = await fetch(`/exercises/${_id}`, {method: 'DELETE'});
        if (response.status === 204) {
            const getResponse = await fetch('/exercises');
            const exercises = await getResponse.json();
            setExercises(exercises.filter (m => m._id !== _id));
            } else {
            console.error(`Failed to delete exercises with ID = ${_id}, status code = ${response.status}`)
            }
    };

    useEffect(() => {
        loadExercises();
    },[] );

    return (
        <>
            <h2>Log of Exercises</h2>
            <p>Use the icons to update the exercise log as applicable. Click the log button above to add a new exercise that has been completed.</p>
            <LogTable exercises={exercises}onDelete={onDeleteExercise} onEdit ={onEditExercise}></LogTable>
            <Link to="/create-exercises">Add an exercise that was completed</Link>
        </>
    );
}

export default HomePage;