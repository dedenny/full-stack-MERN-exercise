// import dependencies 
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import { useState } from 'react';

// import pages
import HomePage from './pages/HomePage';
import CreatePage from './pages/CreatePage';
import EditPage from './pages/EditPage';

//import style 
import './App.css';
import Navigation from './components/Navigation.js';
import {BiRun} from 'react-icons/bi';

function App() {
  const [exercise, setExercise]=useState();

  return (
    <div className="App">
      <Router>
        <header>
        <h1>Exercise Tracking App
        <BiRun className="App-logo"/></h1>
        <p>This application was designed to help you keep track of your exercises that you completed and to keep yourself accountable to reach your personal fitness goals.</p>
        </header>

        <Navigation />

        <main>
        <div className="App-header">

          <Route path="/" exact>
            <HomePage setExercise={setExercise} />
          </Route>

          <Route path="/create-exercises">
            <CreatePage />
          </Route>

          <Route path="/edit-exercises">
            <EditPage exercise={exercise} />
          </Route>

          </div>
          </main>
          <footer>
          <p><cite>&copy; 2022 Deanna Denny Baumer, MBA, RDN </cite></p>
          </footer>
      </Router>
    </div>
  );
}

export default App;