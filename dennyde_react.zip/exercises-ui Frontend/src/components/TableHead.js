import React from 'react';
import {Link} from 'react-router-dom'
import {HiDocumentAdd} from "react-icons/hi";



function TableHead() {
    return (
        <thead>
            <tr>
                <th title ="What is the name of the exercise completed?">Name</th>
                <th title ="How many times was the exercise performed?">Reps</th>
                <th title ="What is the weight of the weights used for the exercise?">Weight</th>
                <th title ="What is the unit of measurement of the weight in kg or lbs?">Unit</th>
                <th title ="What is the date the exercise was performed?">Date</th>
                <th title ="Clicking on the delete icon will remove exercise from log">Delete</th>
                <th title ="Editing will occur on a new screen by redirecting to the Home Page">Edit</th>
                <th><Link to ="../create-exercises"><HiDocumentAdd color = "pink" title = "Add a new exercise completed"></HiDocumentAdd></Link></th>
            </tr>
        </thead>
    );
}

export default TableHead;