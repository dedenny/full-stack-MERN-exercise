import React from 'react';
import {MdDeleteForever, MdEdit} from 'react-icons/md';

function ExLogRow({exercise, onDelete, onEdit}) {
    return (
        <tr>
            <td title ="What is the name of the exercise completed?">{exercise.name}</td>
            <td title ="How many times was the exercise performed?">{exercise.reps}</td>
            <td title="What is the weight of the weights used for the exercise?">{exercise.weight}</td>
            <td title="What is the unit of measurement of the weight in kg or lbs?">{exercise.unit}</td>
            <td title="What is the date the exercise was performed?">{exercise.date.substring(0,10)}</td>
            <td><MdDeleteForever onClick={() => onDelete(exercise.id)} title ="Clicking on the delete icon will remove exercise from log"></MdDeleteForever></td>
            <td><MdEdit onClick={() => onEdit(exercise)} title="Editing will occur on a new screen by redirecting to the Home Page"></MdEdit></td> 
            <td></td>  
            </tr>
    );  
}
export default ExLogRow;