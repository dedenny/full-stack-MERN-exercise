import React from 'react';
import ExLogRow from './ExLogRow';
import TableHead from './TableHead';

function LogTable({ exercises, onDelete, onEdit }) {
    return (
        <table> 
        <caption> Log of Past Exercises</caption>
        <TableHead/>
        <tbody>
            {exercises.map((exercise, i) => <ExLogRow exercise={exercise}
                    key={i} onDelete={onDelete} onEdit={onEdit}/>)}
            </tbody>
            <tfoot>
                
            </tfoot>
        </table>
    );
}

export default LogTable;

