import React from 'react';
import {Link} from 'react-router-dom'
import {HiDocumentAdd} from 'react-icons/hi'
import {TiHome} from 'react-icons/ti'

function Navigation() {
    return (
        <nav className='App-nav'>
            <Link to = "/"><TiHome/>Home Log</Link>
            <Link to = "../create-exercises"><HiDocumentAdd/>Add an Exercise</Link>
        </nav>
    );
}

export default Navigation;