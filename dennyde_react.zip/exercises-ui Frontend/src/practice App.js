
// import dependencies 
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import { useState } from 'react';

// import pages
import HomePage from './pages/HomePage';
import CreatePage from './pages/CreatePage';
import EditPage from './pages/EditPage';

//import style 
import './App.css';
import Navigation from './components/nav.js';
import {FaRunning} from 'react-icons/Fa';

function App() {
  const [exercisesToEdit, setExercisesToEdit]=useState();

  return (
    <div className="App">
      <Router>
        <header>
        <h1>Exercise Tracking App
        <FaRunning className = "App-logo"/>
        </h1>
        <p>This application was designed to help you keep track of your exercises you completed and to keep you accountable to reach your personal fitness goals.</p>
        </header>

        <Navigation />

        <main>
        <div className="App-header">

          <Route path="/" exact>
            <HomePage setExercisesToEdit = {setExercisesToEdit} />
          </Route>

          <Route path="/create-exercises">
            <CreatePage />
          </Route>

          <Route path="/edit-exercises">
            <EditPage exercisesToEdit={exercisesToEdit} />
          </Route>

          </div>
          </main>
          <footer>
          <p><cite>&copy; 2022 Deanna Denny Baumer </cite></p>
          </footer>
      </Router>
    </div>
  );
}

export default App;