//'use strict';

// Get the mongoose object
import mongoose from 'mongoose';



// Prepare to the database exercise_db in the MongoDB server running locally on port 27017
mongoose.connect(
    'mongodb+srv://dennyde:Brandonsouthlyon@assignment5.bjyor.mongodb.net/moviedb?retryWrites=true&w=majority',
    { useNewUrlParser: true }
);

// Connect to to the database
const db = mongoose.connection;

// The open event is called when the database connection successfully opens
db.once('open', () => {
    console.log('Successfully connected to MongoDB using Mongoose!');
});

/**
 * Define the schema
 */
const exerciseSchema = mongoose.Schema({
    name: { type: String, required: true },
    reps: { type: Number, required: true },
    weight: {type: Number, required: true, default: 0 },
    unit: { type: String, required: true, default: 'lbs' },
    date: { type: String, required: true, min: '03-01-2022', default: new Date ()}
});

/**
 * Compile the model from the schema. This must be done after defining the schema.
 */
const Exercise = mongoose.model("Exercises", exerciseSchema);

// For Create
const createExercise = async (name, reps, weight, unit, date) => {
    const exercise = new Exercise({
        name: name,
        reps: reps,
        weight: weight,
        unit: unit,
        date: date
    });
    return exercise.save();
}

// For Retrieve
const findExercise = async () => {
    const query = Exercise.find();
    return query.exec();
}

/**
 * find the exercises with the given ID
* @param {String}id 
*@returns
*/
// find by ID
const findExerciseById = async (id) => {
    const query = Exercise.findById(id);
    return query.exec();
}

// For Replace
const replaceExercise = async (id, name, reps, weight, unit, date) => {
const result = await Exercise.replaceOne({ id: id }, {
        name: name,
        reps: reps,
        weight: weight,
        unit: unit,
        date: date
    });
    console.log(result);
    return{
        id: id,
        name: name,
        reps: reps,
        weight: weight,
        unit: unit,
        date: date }
}
// for Delete
const deleteById = async (id) => {
    const result = await Exercise.deleteOne({ id: id });
    return result.deletedCount;
}



export { createExercise, findExercise, findExerciseById, replaceExercise, deleteById };