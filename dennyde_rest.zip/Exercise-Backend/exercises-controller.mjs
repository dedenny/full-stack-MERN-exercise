// uses REST

// exercise model
import * as exercises from './exercises-model.mjs';

// port
const PORT = 3000;

// dependencies
import express from 'express';
const app = express();

// root of app
app.use(express.static('public'));

// encoding of URL
app.use(express.urlencoded({extended: true
}));

// REST requires JSON MIME type
app.use(express.json());


// Create using POST
app.post('/exercises', (req, res) => {
    exercises.createExercise(req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
    .then(exercise => {
        res.status(201).json(exercise);
    })
    .catch(error =>{
        console.error(error);
        res.status(500).json({Error:'Request Failed to create exercises using POST'});
    });
});


/**
 * Retrive/READ using GET the Exercises corresponding to the ID provided in the URL.
 */
app.get('/exercises', (req, res) => {
   // const exercises = req.params.id;
    exercises.findExercise()
        .then(exercise => { 
            //if (exercise !== null) {
            res.status(200).json(exercise);        
   // } else {
    //    res.status(404).json({ Error: 'Resource not found' });
   // }
    })
        .catch(error => {
            console.log(error);
            res.status(500).json({ Error: 'Request failed to retrieve' });
        });
});


/**
 * Update the Exercises using PUT whose id is provided in the path parameter and set
 * its other factors to the values provided in the body.
 */
app.put('/exercises/:id', (req, res) => {
        exercises.replaceExercise(req.params.id, req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
            .then(exercise => {
                res.status(200).json({exercise});
             })
            .catch(error => {
                console.log(error);
                res.status(500).json({ error: 'Request failed to replace/update' });
            });
    });

/**
 * Delete the exercises whose id is provided in the query parameters
 */
 app.delete('/exercises/:id', (req, res) => {
    console.log(req.params.id);
    exercises.deleteById(req.params.id)
        .then(deletedCount => {
            if (deletedCount === 1) {
                res.status(204).send();
            } else {
                res.status(500).json({ Error: 'Request failed to delete' });
            }
        })
        .catch(error => {
            console.log(error);
            res.send({ error: 'Request failed to delete' });
        });
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});
